CONSENT BASED BULK MERCHANT ONBOARDING - DEVELOPMENT PACKAGE

This package contains:
1. Database scripts
2. UI (JSP) changes
3. Service, DAO, Scheduler code
4. Controller for Yes/No approval
5. Development notes

All files are TEXT ONLY for easy sharing across systems.