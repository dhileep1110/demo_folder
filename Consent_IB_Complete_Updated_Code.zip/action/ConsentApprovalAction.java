package com.app.consent.action;

import com.opensymphony.xwork2.ActionSupport;
import com.app.consent.dao.ConsentDAO;

public class ConsentApprovalAction extends ActionSupport {

    private String token;
    private ConsentDAO consentDAO;

    public String execute() {
        if (consentDAO.approveConsent(token)) {
            return SUCCESS;
        }
        return ERROR;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
