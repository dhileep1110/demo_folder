package com.app.consent.dao;

import org.springframework.jdbc.core.JdbcTemplate;

public class ConsentDAOImpl implements ConsentDAO {

    private JdbcTemplate jdbcTemplate;

    public void insertConsentRecord(int appNo, String mercCode, String email, String token, String userId) {
        String sql = "INSERT INTO mps_email_audt_log (mam_unqe_refno, mam_token, mam_consent_status) VALUES (?, ?, 'PENDING')";
        jdbcTemplate.update(sql, appNo, token);
    }

    public boolean approveConsent(String token) {
        String sql = "UPDATE mps_email_audt_log SET mam_consent_status='APPROVED' WHERE mam_token=?";
        return jdbcTemplate.update(sql, token) > 0;
    }

    public boolean rejectConsent(String token) {
        String sql = "UPDATE mps_email_audt_log SET mam_consent_status='REJECTED' WHERE mam_token=?";
        return jdbcTemplate.update(sql, token) > 0;
    }

    public void expireOldPending() {
        String sql = "UPDATE mps_email_audt_log SET mam_consent_status='EXPIRED' WHERE mam_consent_status='PENDING' AND mam_expiry_dt < CURRENT_TIMESTAMP";
        jdbcTemplate.update(sql);
    }
}
