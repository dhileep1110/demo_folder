package com.app.consent.dao;

public interface ConsentDAO {
    void insertConsentRecord(int appNo, String mercCode, String email, String token, String userId);
    boolean approveConsent(String token);
    boolean rejectConsent(String token);
    void expireOldPending();
}
