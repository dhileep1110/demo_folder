package com.app.consent.service;

import com.app.consent.dao.ConsentDAO;
import java.util.List;

public class ConsentService {

    private ConsentDAO consentDAO;

    public void processExpiry() {
        consentDAO.expireOldPending();
    }
}
