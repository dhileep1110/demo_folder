CONSENT IB IMPLEMENTATION GUIDE
================================
This package contains full working code for IB consent flow.
Framework: Struts2
No SP changes, No Spring

Flow:
- Bulk upload works as-is
- Only SOURCE_TYPE = IB triggers consent
- Token based approval/reject
