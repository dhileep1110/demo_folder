
public class TokenUtil {
    public static String generateToken(String mid) {
        return Base64.getEncoder()
            .encodeToString((mid + System.currentTimeMillis()).getBytes());
    }

    public static String decodeToken(String token) {
        return new String(Base64.getDecoder().decode(token));
    }
}
