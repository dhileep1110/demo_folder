
public interface ConsentDao {
    void insertConsent(String mid, String email, String token);
    void updateApprove(String token);
    void updateReject(String token);
    List<Consent> getApprovedPendingSP();
    void markSPDone(int consentId);
}
