
public interface ConsentService {
    void createConsent(String mid, String email);
    void approveConsent(String token);
    void rejectConsent(String token);
    void triggerApprovedConsents();
}
