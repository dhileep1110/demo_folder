
public class ConsentServiceImpl implements ConsentService {

    private ConsentDao consentDao;
    private EmailService emailService;

    public void createConsent(String mid, String email) {
        String token = TokenUtil.generateToken(mid);
        consentDao.insertConsent(mid, email, token);
        emailService.sendConsentMail(email, token);
    }

    public void approveConsent(String token) {
        consentDao.updateApprove(token);
    }

    public void rejectConsent(String token) {
        consentDao.updateReject(token);
    }

    public void triggerApprovedConsents() {
        List<Consent> list = consentDao.getApprovedPendingSP();
        for(Consent c : list) {
            // CALL EXISTING SP HERE
            consentDao.markSPDone(c.getId());
        }
    }
}
