
public class ConsentQuartzJob implements Job {

    public void execute(JobExecutionContext context) {
        ConsentService service =
            (ConsentService) context.getMergedJobDataMap().get("consentService");
        service.triggerApprovedConsents();
    }
}
