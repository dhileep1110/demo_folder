public class ConsentService {
 private ConsentDAO consentDAO;
 public void createConsent(String fileName, String email, String merchantName, String userId, int expiryDays) {
     consentDAO.insertConsent(fileName, email, merchantName, userId, expiryDays);
 }
 public void approveConsent(String token) {
     consentDAO.updateStatus(Long.parseLong(token), "APPROVED");
 }
 public void rejectConsent(String token) {
     consentDAO.updateStatus(Long.parseLong(token), "REJECTED");
 }
 public void expirePending() {
     consentDAO.expirePending();
 }
}