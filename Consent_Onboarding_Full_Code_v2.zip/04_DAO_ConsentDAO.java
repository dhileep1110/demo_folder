public class ConsentDAO extends JdbcDaoSupport {
 public void insertConsent(String fileName, String email, String merchantName, String userId, int expiryDays) {
     String sql = "INSERT INTO MERCHANT_CONSENT_DTL (CONSENT_ID, FILE_NAME, MERCHANT_EMAIL, MERCHANT_NAME, STATUS, MAIL_SENT_FLAG, MAIL_SENT_DATE, EXPIRY_DATE, CREATED_BY) "
                + "VALUES (SEQ_MERCHANT_CONSENT.NEXTVAL, ?, ?, ?, 'PENDING', 'Y', SYSDATE, SYSDATE+?, ?)";
     getJdbcTemplate().update(sql, fileName, email, merchantName, expiryDays, userId);
 }
 public void updateStatus(Long id, String status) {
     getJdbcTemplate().update("UPDATE MERCHANT_CONSENT_DTL SET STATUS=?, UPDATED_DATE=SYSDATE WHERE CONSENT_ID=?", status, id);
 }
 public void expirePending() {
     getJdbcTemplate().update("UPDATE MERCHANT_CONSENT_DTL SET STATUS='EXPIRED' WHERE STATUS='PENDING' AND SYSDATE>EXPIRY_DATE");
 }
}