@Component
public class ConsentScheduler {
 @Autowired private ConsentService consentService;
 @Value("${consent.scheduler.enabled}") private boolean enabled;
 @Scheduled(cron="${consent.expiry.cron}")
 public void run() {
     if(enabled) consentService.expirePending();
 }
}