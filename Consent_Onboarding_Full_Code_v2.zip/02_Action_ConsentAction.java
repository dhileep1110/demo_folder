public class ConsentAction extends ActionSupport {
 private String token;
 private ConsentService consentService;
 public String approve() {
     consentService.approveConsent(token);
     return SUCCESS;
 }
 public String reject() {
     consentService.rejectConsent(token);
     return SUCCESS;
 }
 public void setToken(String token) { this.token = token; }
}