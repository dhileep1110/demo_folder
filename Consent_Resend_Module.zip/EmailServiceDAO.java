
public int resendConsent(String applNo, String token) {

    String sql =
        "UPDATE MPS_EMAIL_AUDT_LOG " +
        "SET MAM_TOKEN = ?, " +
        "    MAM_SENT_DT = SYSDATE, " +
        "    MAM_EXP_DT = SYSDATE + 2, " +
        "    MAM_CSNT_STUS = 'PENDING', " +
        "    MAM_RESEND_CNT = NVL(MAM_RESEND_CNT,0)+1 " +
        "WHERE MAM_APPL_NO = ?";

    return jdbcTemplate.update(sql, token, applNo);
}
