
public String resendConsent() {

    try {

        String token = UUID.randomUUID().toString();

        int updated = emailServiceDao.resendConsent(applNo, token);

        if(updated > 0) {

            String consentUrl =
                baseUrl + "/consentProcess.action?token=" + token;

            EmailBean emailBean = new EmailBean();
            emailBean.setTo(emailId);
            emailBean.setSubject("Merchant Consent");

            Map<String,Object> map = new HashMap<String,Object>();
            map.put("consentUrl", consentUrl);

            emailBean.setBodyVariables(map);
            emailBean.setVelocityTemplateName("ConsentTemplate.vm");

            emailService.sendEmail(emailBean);

            addActionMessage("Consent mail resent successfully");
        }

    } catch(Exception e) {
        loggerUtil.error("Error while resending consent", e);
        addActionError("Unable to resend consent");
    }

    return SUCCESS;
}
